import json
import boto3
import pandas as pd
from io import BytesIO
import pyarrow as pa
import pyarrow.parquet as pq
from nltk.sentiment.vader import SentimentIntensityAnalyzer

# Load NLP tools once (Lambda cold start)
analyzer = SentimentIntensityAnalyzer()
#nlp = spacy.load("en_core_web_sm")

def get_sentiment(text):
    if not text:
        return "neutral"
    score = analyzer.polarity_scores(text)["compound"]
    if score >= 0.3:
        return "positive"
    elif score <= -0.3:
        return "negative"
    else:
        return "neutral"

def lambda_handler(event, context):
    s3 = boto3.client("s3")

    bucket = event["Records"][0]["s3"]["bucket"]["name"]
    key = event["Records"][0]["s3"]["object"]["key"]
    print(f"Triggered by file: {bucket}/{key}")

    response = s3.get_object(Bucket=bucket, Key=key)
    raw_data = json.loads(response["Body"].read())

    df = pd.json_normalize(raw_data)
    df = df[["publishedAt", "title", "source.name"]].rename(
        columns={"publishedAt": "timestamp", "source.name": "source"}
    )

    # Enrich
    df["sentiment"] = df["title"].apply(get_sentiment)

    # Save to Parquet
    table = pa.Table.from_pandas(df)
    buffer = BytesIO()
    pq.write_table(table, buffer)
    buffer.seek(0)

    output_key = f"{key.split('/')[-1].replace('.json', '.parquet')}"
    s3.put_object(
        Bucket="news-nl-enriched",
        Key=output_key,
        Body=buffer.getvalue(),
        ContentType="application/octet-stream"
    )

    print(f"Saved enriched data to: {output_key}")
    return {
        "statusCode": 200,
        "message": f"Enriched data saved to {output_key}"
    }
